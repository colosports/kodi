##==============
## Installer
##===============
import xbmc,xbmcaddon,xbmcgui,os,time
import skindefault
import downloader
import extract
import common

AddonID = 'plugin.video.tampablackbox'
ADDON=xbmcaddon.Addon(id='plugin.video.tampablackbox')
HOME =  xbmc.translatePath('special://home/')   
PATH = "Tampa Black Box"
VERSION = "2020.12.05"

##============
##   WIZARD
##============
def WIZARD(name,url,description):
    AddonTitle = "[COLOR aqua]Tampa Black Box[/COLOR]"
    KODIVERSION = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    dialog = xbmcgui.Dialog()
    if KODIVERSION < 16.0:
        dialog.ok("[COLOR=red][B]WARNING !!! [/COLOR][/B]", "Your device has an old Version of Kodi that should be upgraded.")
        return
    else:
        skindefault.SetDefaultSkin()
        dp = xbmcgui.DialogProgress()

        ##  Fresh Start
        dp.create(AddonTitle,"Removing Old Addons",'In Progress.............','Please Wait. Do not cancel!')
        common.FRESHSTARTBUILD()
        time.sleep(2)

        ##  Download
        dp.create(AddonTitle,"Downloading the Latest Build... ",'','Please Wait')
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, name+'.zip')
        try:
            os.remove(lib)
        except:
            pass
        downloader.download(url, lib, dp)
        time.sleep(2)

        ##  Extract from Zip File
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        dp.update(0,"", "Extracting Files from Zip File...")
        extract.all(lib,addonfolder,dp)

        ##  Cleanup Kodi
        common.CLEANUP(url)
        time.sleep(2)

        ##  Force Quit Kodi
        common.TIMER(10,"[COLOR aqua][B]DOWNLOAD is Complete[/B][/COLOR]","Kodi will attempt to shutdown in: ", "[COLOR yellow][B]Remove the power cable[/B][/COLOR] from your device [COLOR red][B]AFTER[/B][/COLOR] the countdown.")
        common.killxbmc()
